#import <Preferences/PSListController.h>

@interface @@CLASSPREFIX@@RootListController : PSListController

@end
