#include <stdio.h>

int main(int argc, char *argv[], char *envp[]) {
	printf("Hello world!\n");
	return 0;
}
