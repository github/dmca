// Umbrella header for @@PROJECTNAME@@.
// Add import lines for each public header, like this: #import <@@PROJECTNAME@@/XXXAwesomeClass.h>
// Don’t forget to also add them to @@PROJECTNAME@@_PUBLIC_HEADERS in your Makefile!
